<?php
$test = array('fatalError' => 'Testing', 'postedStories' => array(), 'postedWarningStories' => array(), 'failedStories' => array());
echo json_encode($test);
 ?>
